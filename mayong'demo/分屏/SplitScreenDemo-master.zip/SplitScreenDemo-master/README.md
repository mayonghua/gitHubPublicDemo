# 简单的分屏 Demo
基于 autoLayout 和 Size Classes  支持竖屏上下分屏, 和横平左右分屏的自动切换。
Preview
===============

- ![程序截图](/Simulator Screen Shot 2016年5月26日 上午1.25.46.png)
- ![程序截图](/Simulator Screen Shot 2016年5月26日 上午1.25.49.png)
- ![](Simulator Screen Shot 2016年5月26日 上午1.25.54.png)
- ![](Simulator Screen Shot 2016年5月26日 上午1.26.03.png)
- ![](Simulator Screen Shot 2016年5月26日 上午1.26.06.png)


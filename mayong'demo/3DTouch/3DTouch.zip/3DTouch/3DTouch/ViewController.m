//
//  ViewController.m
//  3DTouch
//
//  Created by apple on 16/12/1.
//  Copyright © 2016年 YJS. All rights reserved.
//

#import "ViewController.h"
#import "OneViewController.h"
#import "TwoViewController.h"
#import "ThreeViewController.h"
#import "FourViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    // Do any additional setup after loading the view, typically from a nib.
    [self registerNotification];
}

- (void)registerNotification{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onesNotification) name:@"ONES" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(twosNotification) name:@"TWOS" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(threesNotification) name:@"THREES" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(foursNotification) name:@"FOURS" object:nil];
}

/**跳转页面一*/
- (void)onesNotification{
    [self presentViewController:[OneViewController new] animated:YES completion:nil];
}

/**跳转页面二*/
- (void)twosNotification{
    [self presentViewController:[TwoViewController new] animated:YES completion:nil];
}

/**跳转页面三*/
- (void)threesNotification{
    [self presentViewController:[ThreeViewController new] animated:YES completion:nil];
}

/**跳转页面四*/
- (void)foursNotification{
    [self presentViewController:[FourViewController new] animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

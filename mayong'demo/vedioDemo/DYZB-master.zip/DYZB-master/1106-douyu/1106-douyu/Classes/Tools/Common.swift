//
//  Common.swift
//  1106-douyu
//
//  Created by targetcloud on 2016/11/6.
//  Copyright © 2016年 targetcloud. All rights reserved.
//

import UIKit

let kStatusBarH : CGFloat = 20
let kNavBarH :CGFloat = 44
let kScreenW = UIScreen.main.bounds.width
let kScreenH = UIScreen.main.bounds.height
let kTabBarH :CGFloat = 44
let kMenuViewH : CGFloat = 200

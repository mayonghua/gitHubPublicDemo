//
//  AppDelegate.h
//  BANetManagerDemo
//
//  Created by 博爱 on 16/6/3.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

